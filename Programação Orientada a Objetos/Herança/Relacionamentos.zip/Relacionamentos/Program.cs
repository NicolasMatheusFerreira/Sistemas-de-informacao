﻿using System;

namespace Relacionamentos
{

    class Program
    {
        private static void Main(string[] args)
        {
            Associacao.Executar();
            
        }
    }
}