﻿// See https://aka.ms/new-console-template for more information
Questao1.testar();
