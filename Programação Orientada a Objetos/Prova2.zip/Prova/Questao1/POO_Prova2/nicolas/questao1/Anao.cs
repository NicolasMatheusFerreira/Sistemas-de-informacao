public sealed class Anao : Personagem {

    public Anao() {
    }

    public Anao(string nome, string descricao) :base(nome, descricao){
    }

    override public void atacar() {
        Console.WriteLine("Anao atacando!");
    }
    override public void correr() {
        Console.WriteLine("Anao correndo!");
    }
    override public void defender() {
        Console.WriteLine("Anao defendendo!");
    }

    override public void mostrar() {
        Console.WriteLine(descricao);
        atacar();
        correr();
        defender();
    }
}