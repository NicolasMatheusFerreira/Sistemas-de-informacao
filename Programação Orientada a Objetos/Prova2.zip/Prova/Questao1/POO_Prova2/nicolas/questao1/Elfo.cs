public sealed class Elfo : Personagem {

    public Elfo() {
    }

    public Elfo(string nome, string descricao) :base(nome, descricao){
    }

    override public void atacar() {
        Console.WriteLine("Elfo atacando!");
    }
    override public void correr() {
        Console.WriteLine("Elfo correndo!");
    }
    override public void defender() {
        Console.WriteLine("Elfo defendendo!");
    }

    override public void mostrar() {
        Console.WriteLine(descricao);
        atacar();
        correr();
        defender();
    }
}