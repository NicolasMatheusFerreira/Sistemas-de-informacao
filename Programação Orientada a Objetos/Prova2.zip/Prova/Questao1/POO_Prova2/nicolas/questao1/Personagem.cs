public abstract class Personagem {

    protected string nome;
    protected string descricao;

    // Construtores
    public Personagem() {}

    public Personagem(string nome, string descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    // Setters e Getters
    public void setNome(string nome) {
        this.nome = nome;
    }
    public string getNome() {
        return this.nome;
    }

    public void setDescricao(string descricao) {
        this.descricao = descricao;
    }
    public string getDescricao() {
        return this.descricao;
    }

    // Métodos

    abstract public void atacar();
    abstract public void correr();
    abstract public void defender();
    abstract public void mostrar();

}