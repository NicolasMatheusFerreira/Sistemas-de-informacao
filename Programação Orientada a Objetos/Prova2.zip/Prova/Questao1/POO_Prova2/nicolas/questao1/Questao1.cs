using System;

public class Questao1 {
    public static void testar() {
        
        Anao marquinhos = new Anao("Marquinhos", "Descricao: Anao ser resistente, com baravura e luta corpo a corpo.");
        Elfo doby = new Elfo("Doby", "Descricao: Elfo ser mitologico que vive centenas de anos, excelente para ataque a distancia.");

        marquinhos.mostrar();
        doby.mostrar();
    }
}