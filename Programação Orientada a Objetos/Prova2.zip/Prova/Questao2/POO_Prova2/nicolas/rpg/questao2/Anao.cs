public sealed class Anao : Personagem, IAtaque {

    public Anao() {
    }

    public Anao(string nome, string descricao) :base(nome, descricao){
    }

    public void atacar() {
        Console.WriteLine("O Anao e um personagem que gosta de atacar!");
    }
    override public void mostrar() {
        Console.WriteLine(descricao);
        atacar();
    }
}