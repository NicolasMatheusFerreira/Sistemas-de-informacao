public sealed class Elfo : Personagem, IAtaque {

    public Elfo() {
    }

    public Elfo(string nome, string descricao) :base(nome, descricao){
    }

    public void atacar() {
        Console.WriteLine("O Elfo e um personagem que gosta de atacar!");
    }
    override public void mostrar() {
        Console.WriteLine(descricao);
        atacar();
    }
}