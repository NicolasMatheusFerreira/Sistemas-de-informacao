public sealed class Halfling : Personagem, IHalfling {

    public Halfling() {
    }

    public Halfling(string nome, string descricao) :base(nome, descricao){
    }

    public void fugir() {
        Console.WriteLine("Fugir: Partir em retirada atras uma cortina de poeira.");
    }
    override public void mostrar() {
        Console.WriteLine(descricao);
        fugir();
    }
}