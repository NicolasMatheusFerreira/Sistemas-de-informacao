public interface IAtaque {

    void atacar();
}