public interface IHalfling {

    void fugir();
}