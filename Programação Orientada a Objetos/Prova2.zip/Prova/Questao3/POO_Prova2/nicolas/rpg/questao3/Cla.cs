public class Cla {

    protected string nome;
    protected string origem;

    public Cla() {
    }

    public Cla(string nome, string origem) {

        this.nome = nome;
        this.origem = origem;
    }

    public void setNome(string nome) {
        this.nome = nome;
    }
    public string getNome() {
        return this.nome;
    }

    public void setOrigem(string origem) {
        this.origem = origem;
    }
    public string getOrigem() {
        return this.origem;
    }
}