public abstract class Personagem {

    protected string nome;
    protected string descricao;
    Cla cla;

    // Construtores
    public Personagem() {}

    public Personagem(string nome, string descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    // Setters e Getters
    public void setNome(string nome) {
        this.nome = nome;
    }
    public string getNome() {
        return this.nome;
    }

    public void setDescricao(string descricao) {
        this.descricao = descricao;
    }
    public string getDescricao() {
        return this.descricao;
    }

    public void mostrarCla(string nomeCla, string origemCla) {
        cla = new Cla(nomeCla, origemCla);
        Console.WriteLine(cla.getNome());
        Console.WriteLine(cla.getOrigem());
    }
    // Métodos
    
    //abstract public void correr();
    //abstract public void defender();
    abstract public void mostrar();

}