using System;

public class Questao3 {
    public static void testar() {
        
        Anao marquinhos = new Anao("Marquinhos", "Descricao: Anao ser resistente, com baravura e luta corpo a corpo.");
        Elfo doby = new Elfo("Doby", "Descricao: Elfo ser mitologico que vive centenas de anos, excelente para ataque a distancia.");
        Halfling guga = new Halfling("Guga", "Os Halflings sao personagens muito conhecidos por pelo alto poder de fuga!");

        Console.Write("Marquinhos (Anao): ");
        marquinhos.mostrar();
        marquinhos.mostrarCla("Tupi","Brasil");
        
        Console.Write("\nDoby (Elfo): ");
        doby.mostrar();
        marquinhos.mostrarCla("Gangus","Australia");

        Console.Write("\nGuga (Halfling): ");
        guga.mostrar();
        marquinhos.mostrarCla("Xan-Xi Dragon","China");
    }
}