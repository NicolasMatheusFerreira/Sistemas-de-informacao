public sealed class Anao : Personagem, IAtaque, IValentia {

    public Anao() { 

        forca = 100.0; 
        distanciaAtaque(0);     
    }

    public Anao(string nome, string descricao) :base(nome, descricao){

        forca = 100.0;    
        distanciaAtaque(0);
    }

    public void aumentarForca() {
        forca = forca * 3;
        Console.WriteLine("Forca aumentada em 3 vezes!!! Forca aumentada: "+this.forca);
    }
    public void atacar() {
        Console.WriteLine("O Anao e um personagem que gosta de atacar!");
    }

    override public void distanciaAtaque(int x) {
        this.distancia = x;
    }

    override public void mostrar() {
        Console.WriteLine(descricao);
        atacar();
         Console.WriteLine("Forca original: "+this.forca);
        aumentarForca();
        Console.WriteLine("Distancia de ataque: "+distancia);
    }
}