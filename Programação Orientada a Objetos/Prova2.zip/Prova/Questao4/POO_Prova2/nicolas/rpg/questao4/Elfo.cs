public sealed class Elfo : Personagem, IAtaque {

    public Elfo() {
        distanciaAtaque(100);     
    }

    public Elfo(string nome, string descricao) :base(nome, descricao){
        distanciaAtaque(100);     
    }

    override public void distanciaAtaque(int x) {
        this.distancia = x;
    }

    public void atacar() {
        Console.WriteLine("O Elfo e um personagem que gosta de atacar!");
    }
    override public void mostrar() {
        Console.WriteLine(descricao);
        atacar();
        Console.WriteLine("Distancia de ataque: "+distancia);
    }
}