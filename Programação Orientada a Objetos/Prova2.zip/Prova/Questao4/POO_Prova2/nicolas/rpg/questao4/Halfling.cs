public sealed class Halfling : Personagem, IHalfling {

    public Halfling() {
        distanciaAtaque(500);     
    }

    public Halfling(string nome, string descricao) :base(nome, descricao){
        distanciaAtaque(500);     
    }

    public void fugir() {
        Console.WriteLine("Fugir: Partir em retirada atras uma cortina de poeira.");
    }

    override public void distanciaAtaque(int x) {
        this.distancia = x;
    }

    override public void mostrar() {
        Console.WriteLine("Os Halflings sao personagens muito conhecidos por pelo alto poder de fuga!");
        fugir();
        Console.WriteLine("Distancia de ataque: "+distancia);
    }
}