public interface IValentia {

    void aumentarForca();
}